-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2018 at 05:07 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ipk`
--
CREATE DATABASE IF NOT EXISTS `ipk` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ipk`;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `admin_id` int(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`admin_id`, `username`, `password`) VALUES
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06'),
(0, 'ipkpahang', 'ipkpahang06');

-- --------------------------------------------------------

--
-- Table structure for table `senaraikontrak`
--

CREATE TABLE `senaraikontrak` (
  `id` int(50) NOT NULL,
  `nokontrak` varchar(50) NOT NULL,
  `namakontrak` varchar(500) NOT NULL,
  `tarikhkontrak` date NOT NULL,
  `tarikhkontrakend` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `pcname` varchar(200) NOT NULL,
  `pcvalue` int(200) NOT NULL,
  `pcspec` varchar(200) NOT NULL,
  `printname` varchar(200) NOT NULL,
  `printvalue` int(200) NOT NULL,
  `printspec` varchar(200) NOT NULL,
  `notename` varchar(200) NOT NULL,
  `notevalue` int(200) NOT NULL,
  `notespec` varchar(200) NOT NULL,
  `proname` varchar(200) NOT NULL,
  `provalue` int(200) NOT NULL,
  `prospec` varchar(200) NOT NULL,
  `scaname` varchar(200) NOT NULL,
  `scavalue` int(200) NOT NULL,
  `scaspec` varchar(200) NOT NULL,
  `camname` varchar(200) NOT NULL,
  `camvalue` int(200) NOT NULL,
  `camspec` varchar(200) NOT NULL,
  `sername` varchar(200) NOT NULL,
  `servalue` int(200) NOT NULL,
  `serspec` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `senaraikontrak`
--

INSERT INTO `senaraikontrak` (`id`, `nokontrak`, `namakontrak`, `tarikhkontrak`, `tarikhkontrakend`, `status`, `pcname`, `pcvalue`, `pcspec`, `printname`, `printvalue`, `printspec`, `notename`, `notevalue`, `notespec`, `proname`, `provalue`, `prospec`, `scaname`, `scavalue`, `scaspec`, `camname`, `camvalue`, `camspec`, `sername`, `servalue`, `serspec`) VALUES
(80, 'KDN/POL/182/1998', 'Pembekalan perkakasan dan perisian komputer untuk projek sistem pembayaran kompaun trafik berkomputer (traffic COPS) FASA 1 ', '2018-10-01', '2018-10-31', 'NOT ACTIVE', 'Fujitsu', 7, '4GB RAM', 'OKI', 7, '2GB RAM', 'LIES', 9, '4GB RAM', 'CANON', 34, '5GB RAM', 'HP', 7, '5GB RAM', 'NEX', 7098, '5GB RAM', 'CISCO', 9, '4GB RAM'),
(85, 'KDN/POL/182/1993', 'Pembekalan perkakasan dan perisian komputer untuk projek sistem pembayaran kompaun trafik berkomputer (traffic COPS) FASA 1 ', '2018-11-24', '2019-01-11', 'ACTIVE', 'Fujitsu', 9, '4GB RAM', 'OKI', 98657, '2GB RAM', 'LIES', 9, '4GB RAM', 'CANON', 7, '5GB RAM', 'HP', 3, '5GB RAM', 'NEX', 7, '5GB RAM', 'CISCO', 9, '4GB RAM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `senaraikontrak`
--
ALTER TABLE `senaraikontrak`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `senaraikontrak`
--
ALTER TABLE `senaraikontrak`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
